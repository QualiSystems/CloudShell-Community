from cloudshell.cli.command_mode import CommandMode
from cloudshell.devices.cli_handler_impl import CliHandlerImpl

# this is to overcome the dsa size for alcatel gpon ssh
import cryptography.hazmat.primitives.asymmetric.dsa as dsamod


class HfcCliHandler(CliHandlerImpl):
    def __init__(self, cli, resource_config, logger, api):
        super(HfcCliHandler, self).__init__(cli, resource_config, logger, api)

        # initialize command modes
        self._jump_host_mode = self.initialize_jump_host_mode()
        self._device_mode = self.initialize_device_mode()
        # Connecting modes
        self._jump_host_mode.add_child_node(self._device_mode)

    @property
    def resource_address(self):
        return self.resource_config.console_server_ip_address

    @property
    def username(self):
        return self.resource_config.console_user

    @property
    def password(self):
        return self._api.DecryptPassword(self.resource_config.console_password).Value

    def initialize_jump_host_mode(self):
        """Jump Host Command Mode
        :rtype: CommandMode
        """
        jump_host_prompt_re = r'.+$'
        return CommandMode(jump_host_prompt_re)

    def initialize_device_mode(self):
        device_host = super(HfcCliHandler, self).resource_address
        device_user = super(HfcCliHandler, self).username
        device_password = super(HfcCliHandler, self).password
        device_prompt_re = r'.+#'

        return CommandMode(device_prompt_re,
                           enter_command='ssh {}@{}'.format(device_user, device_host),
                           exit_command='exit',
                           enter_action_map={
                               r'password:': lambda session, logger: session.send_line(
                                   device_password, logger)})

    @property
    def enable_mode(self):
        return self.jump_mode

    @property
    def config_mode(self):
        return self.device_mode

    @property
    def jump_mode(self):
        return self._jump_host_mode

    @property
    def device_mode(self):
        return self._device_mode

    def jump_host_service(self):
        """
        Default mode session
        :return:
        """
        return self.get_cli_service(self.jump_mode)

    def device_host_service(self):
        """
        Config mode session
        :return:
        """
        return self.get_cli_service(self.device_mode)

    # def _ssh_session(self):
    #     return AccessSSHSession(self.resource_address, self.username, self.password, self.port, self.on_session_start)
    #
    # def _telnet_session(self):
    #     return JuniperTelnetSession(self.resource_address, self.username, self.password, self.port,
    #                                 self.on_session_start)

    def my_moc(self):
        print 'modified'

    dsamod._check_dsa_parameters.__code__ = my_moc.__code__
