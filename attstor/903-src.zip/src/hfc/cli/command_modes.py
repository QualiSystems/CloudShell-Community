from collections import OrderedDict
from pprint import pprint
from cloudshell.cli.command_mode import CommandMode
from cloudshell.shell.core.api_utils import decrypt_password
from cloudshell.cli.session.ssh_session import SSHSession
from cloudshell.cli.cli import CLI
# gk reg exp for prompt. only using defaul command mode. not using shell mode.

class DefaultCommandMode(CommandMode):

    def __init__(self, resource_config, api):
        self.resource_config = resource_config
        self._api = api

        jump_host_username=resource_config.attributes.get('HfcShell.User')
        jump_host_host=resource_config.attributes.get('HfcShell.host')
        jump_host_password=resource_config.attributes.get('HfcShell.Password')
        device_host=resource_config.attributes.get('HfcShell.Console Server IP Address')
        device_user = resource_config.attributes.get('HfcShell.Console User')
        device_password = resource_config.attributes.get('HfcShell.Console Password')


        #jump_host_username = 'autouser'
        #jump_host_password = 'Aut@ntf@1010'
        #jump_host_host = '172.28.18.210'
        jump_host_prompt_re = r'.+$'

        #device_host = '172.28.17.251'
        #device_user = 'autouser'
        #device_password = 'Aut@ntf@1010'
        device_prompt_re = r'.+#'

        jump_host_mode = CommandMode(jump_host_prompt_re)

        device_host_mode = CommandMode(device_prompt_re,
                                       enter_command='ssh {}@{}'.format(device_user, device_host),
                                       exit_command='exit',
                                       enter_action_map={
                                           r'password:': lambda session, logger: session.send_line(
                                               device_password, logger)})
        # Connecting modes
        jump_host_mode.add_child_node(device_host_mode)

        cli = CLI()

        ssh_session = SSHSession(jump_host_host, jump_host_username, jump_host_password)
        with cli.get_session([ssh_session], device_host_mode) as session:
            print session.send_command('')
            pprint(session)


def enter_actions(self, cli_operations):
    cli_operations.send_command('environment no more')


def enter_action_map(self):
    return OrderedDict()


def enter_error_map(self):
    return OrderedDict([(r'[Ee]rror:', 'Command error')])


def exit_action_map(self):
    return OrderedDict()


def exit_error_map(self):
    return OrderedDict([(r'[Ee]rror:', 'Command error')])


CommandMode.RELATIONS_DICT = {
    DefaultCommandMode: {

    }
}
#DefaultCommandMode(resource_config='', api='')