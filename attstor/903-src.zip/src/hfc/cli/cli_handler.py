
from cloudshell.cli.command_mode_helper import CommandModeHelper
from cloudshell.devices.cli_handler_impl import CliHandlerImpl
from command_modes import DefaultCommandMode


#this is to overcome the dsa size for alcatel gpon ssh
import cryptography.hazmat.primitives.asymmetric.dsa as dsamod

class HfcCliHandler(CliHandlerImpl):
    def __init__(self, cli, resource_config, logger, api):
        super(HfcCliHandler, self).__init__(cli, resource_config, logger, api)
        self.modes = CommandModeHelper.create_command_mode(resource_config, api)


    @property
    def enable_mode(self):
        return self.modes[DefaultCommandMode]

    @property
    def config_mode(self):
        return self.modes[DefaultCommandMode]

    def default_mode_service(self):
        """
        Default mode session
        :return:
        """
        return self.get_cli_service(self.enable_mode)

    def config_mode_service(self):
        """
        Config mode session
        :return:
        """
        return self.get_cli_service(self.config_mode)

    # def _ssh_session(self):
    #     return AccessSSHSession(self.resource_address, self.username, self.password, self.port, self.on_session_start)
    #
    # def _telnet_session(self):
    #     return JuniperTelnetSession(self.resource_address, self.username, self.password, self.port,
    #                                 self.on_session_start)

    def my_moc(self):
        print 'modified'

    dsamod._check_dsa_parameters.__code__ = my_moc.__code__

