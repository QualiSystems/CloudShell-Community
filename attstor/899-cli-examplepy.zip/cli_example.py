from cloudshell.cli.cli import CLI
from cloudshell.cli.command_mode import CommandMode
from cloudshell.cli.session.ssh_session import SSHSession

if __name__ == '__main__':
    jump_host_username = 'user1'
    jump_host_password = 'password1'
    jump_host_host = '192.168.28.34'
    device_host = '192.168.51.221'
    device_user = 'user2'
    device_password = 'password2'

    jump_host_mode = CommandMode(r'.+$')
    device_host_default_mode = CommandMode(r'.+%', enter_command='ssh {}@{}'.format(device_user, device_host),
                                           exit_command='exit',
                                           enter_action_map={
                                               r'password:': lambda session, logger: session.send_line(
                                                   device_password, logger)})
    device_host_enable_mode = CommandMode(r'.+>', enter_command='cli', exit_command='exit')

    device_host_default_mode.add_child_node(device_host_enable_mode)
    jump_host_mode.add_child_node(device_host_default_mode)

    cli = CLI()

    ssh_session = SSHSession(jump_host_host, jump_host_username, jump_host_password)
    with cli.get_session([ssh_session], device_host_enable_mode) as session:
        print session.send_command('show chassis hardware')
