from threading import Thread

from cloudshell.shell.core.driver_context import ResourceCommandContext, ResourceContextDetails, \
    ReservationContextDetails
from mock import patch, create_autospec

from driver import HfcShellDriver



request = """{
  "driverRequest" : {
    "actions" : [{
      "connectionId" : "457238ad-4023-49cf-8943-219cb038c0dc",
      "connectionParams" : {
        "vlanId" : "45",
        "mode" : "Access",
        "vlanServiceAttributes" : [{
          "attributeName" : "QnQ",
          "attributeValue" : "True",
          "type" : "vlanServiceAttribute"
        }, {
          "attributeName" : "CTag",
          "attributeValue" : "",
          "type" : "vlanServiceAttribute"
        }, {
          "attributeName" : "Isolation Level",
          "attributeValue" : "Shared",
          "type" : "vlanServiceAttribute"
        }, {
          "attributeName" : "Access Mode",
          "attributeValue" : "Access",
          "type" : "vlanServiceAttribute"
        }, {
          "attributeName" : "VLAN ID",
          "attributeValue" : "876",
          "type" : "vlanServiceAttribute"
        }, {
          "attributeName" : "Virtual Network",
          "attributeValue" : "876",
          "type" : "vlanServiceAttribute"
        }, {
          "attributeName" : "Pool Name",
          "attributeValue" : "",
          "type" : "vlanServiceAttribute"
        }
        ],
        "type" : "setVlanParameter"
      },
      "connectorAttributes" : [],
      "actionId" : "457238ad-4023-49cf-8943-219cb038c0dc_4244579e-bf6f-4d14-84f9-32d9cacaf9d9",
      "actionTarget" : {
        "fullName" : "Router/Chassis 1/Module1/SubModule1/ge-0-0-6",
        "fullAddress" : "192.168.28.150/1/1/1/7",
        "type" : "actionTarget"
      },
      "customActionAttributes" : [],
      "type" : "setVlan"
    }
    ]
  }
}"""

request_range = """{"driverRequest":
    {"actions": [
        {"connectionId": "afba4ccf-5f05-4cf3-a065-da1f7b2b4b28",
         "connectionParams":
             {"vlanId": "500", "mode": "Access",
              "vlanServiceAttributes": [
                  {"attributeName": "QnQ",
                   "attributeValue": "False",
                   "type": "vlanServiceAttribute"},
                  {"attributeName": "CTag",
                   "attributeValue": "",
                   "type": "vlanServiceAttribute"},
                  {
                      "attributeName": "Allocation Ranges",
                      "attributeValue": "500-600",
                      "type": "vlanServiceAttribute"},
                  {
                      "attributeName": "Isolation Level",
                      "attributeValue": "Exclusive",
                      "type": "vlanServiceAttribute"},
                  {
                      "attributeName": "Access Mode",
                      "attributeValue": "Access",
                      "type": "vlanServiceAttribute"},
                  {
                      "attributeName": "VLAN ID",
                      "attributeValue": "",
                      "type": "vlanServiceAttribute"},
                  {
                      "attributeName": "Pool Name",
                      "attributeValue": "",
                      "type": "vlanServiceAttribute"},
                  {
                      "attributeName": "Virtual Network",
                      "attributeValue": "500",
                      "type": "vlanServiceAttribute"}],
              "type": "setVlanParameter"},
         "connectorAttributes": [],
         "actionId": "afba4ccf-5f05-4cf3-a065-da1f7b2b4b28_43793b49-500d-413f-9ea0-eb61d51a7af0",
         "actionTarget": {
             "fullName": "Junos US 192.168.28.150/Chassis 1/Module 1/SubModule 1/ge-0-0-2",
             "fullAddress": "192.168.28.150/CH1/M1/SM1/P3",
             "type": "actionTarget"}, "customActionAttributes": [],
         "type": "setVlan"},
        {"connectionId": "79b1b38b-e5a4-4310-9374-5a9c4b3b4aeb",
         "connectionParams":
             {"vlanId": "100-150", "mode": "Trunk",
              "vlanServiceAttributes": [
                  {"attributeName": "QnQ",
                   "attributeValue": "True",
                   "type": "vlanServiceAttribute"},
                  {"attributeName": "CTag",
                   "attributeValue": "",
                   "type": "vlanServiceAttribute"},
                  {
                      "attributeName": "Isolation Level",
                      "attributeValue": "Shared",
                      "type": "vlanServiceAttribute"},
                  {
                      "attributeName": "Access Mode",
                      "attributeValue": "Trunk",
                      "type": "vlanServiceAttribute"},
                  {
                      "attributeName": "VLAN ID",
                      "attributeValue": "100-150",
                      "type": "vlanServiceAttribute"},
                  {
                      "attributeName": "Pool Name",
                      "attributeValue": "",
                      "type": "vlanServiceAttribute"},
                  {
                      "attributeName": "Virtual Network",
                      "attributeValue": "100-150",
                      "type": "vlanServiceAttribute"}],
              "type": "setVlanParameter"},
         "connectorAttributes": [],
         "actionId": "79b1b38b-e5a4-4310-9374-5a9c4b3b4aeb_b9fe533a-a7f1-40b3-a070-ae62f0dac77d",
         "actionTarget": {
             "fullName": "Junos US 192.168.28.150/Chassis 1/Module 1/SubModule 1/ge-0-0-0",
             "fullAddress": "192.168.28.150/CH1/M1/SM1/P1",
             "type": "actionTarget"}, "customActionAttributes": [],
         "type": "setVlan"}]}}"""


#address = '10.5.1.2:1223'
#address = '172.28.238.212'
address = '172.28.18.210'
#address = '192.168.216.48'

user = 'autouser'
#user = 'autouser'
#user = 'test1'
# password = 'P0G8gOpDHL0c52ROLdsaVQ=='
password = 'Aut@ntf@1010'
#password = 'Test11!!'
#password = 'Auto@1010'
# password = '30auto20'
port = 22
# port = 4422
# enable_password = 'NuCpFxP8cJMCic8ePJokug=='
# auth_key = 'h8WRxvHoWkmH8rLQz+Z/pg=='
# api_port = 8029


# context = ResourceCommandContext(*[None]*4)
# context.resource = ResourceContextDetails(*[None]*13)
# context.resource.name = 'dsada'
# context.resource.fullname = 'TestAireOS'
# context.reservation = ReservationContextDetails(*[None]*7)
# context.reservation.reservation_id = 'test_id'
# context.resource.attributes = {}
# context.resource.attributes['User'] = user
# context.resource.attributes['Password'] = password
# context.resource.attributes['host'] = address
# context.resource.attributes['Enable Password'] = enable_password
# context.resource.attributes['Port'] = port
# # context.resource.attributes['Backup Location'] = 'tftp://172.25.10.96/AireOS_test'
# context.resource.attributes['Backup Location'] = 'ftp://juniper:juniper@192.168.85.16'
# context.resource.address = address
# # context.connectivity = ConnectivityContext()
# # context.connectivity.admin_auth_token = auth_key
# # context.connectivity.server_address = '10.5.1.2'
# # context.connectivity.cloudshell_api_port = api_port
# context.resource.attributes['SNMP Version'] = '2'
# context.resource.attributes['SNMP Read Community'] = 'public'
# context.resource.attributes['CLI Connection Type'] = 'ssh'
# context.resource.attributes['Enable SNMP'] = 'False'
# context.resource.attributes['Disable SNMP'] = 'False'
# context.resource.attributes['CLI Connection Type'] = 'ssh'
# context.resource.attributes['Sessions Concurrency Limit'] = '1'
def gen_context(shell_name):
    context = create_autospec(ResourceCommandContext)
    context.resource = create_autospec(ResourceContextDetails)
    context.resource.name = 'Hfc'
    context.resource.fullname = 'Hfc'
    context.resource.family = 'CS_Switch'
    context.reservation = create_autospec(ReservationContextDetails)
    context.reservation.reservation_id = 'test_id'
    context.resource.attributes = {}
    context.resource.attributes['{}User'.format(shell_name)] = user
    context.resource.attributes['{}Password'.format(shell_name)] = password
    context.resource.attributes['{}host'.format(shell_name)] = address
    # context.resource.attributes['{}Enable Password'.format(shell_name)] = enable_password
    # context.resource.attributes['{}CLI TCP Port'.format(shell_name)] = port
    # context.resource.attributes['Backup Location'] = 'tftp://172.25.10.96/AireOS_test'
    # context.resource.attributes['{}Backup Location'.format(shell_name)] = 'ftp://junos:junos@192.168.85.47'
    # context.resource.attributes['{}Backup Location'.format(shell_name)] = 'ftp://user:pass@172.29.128.11'
    context.resource.attributes['{}Backup Location'.format(shell_name)] = '172.16.1.20'
    context.resource.attributes['{}Backup Type'.format(shell_name)] = 'tftp'
    context.resource.address = address
    # context.connectivity = ConnectivityContext()
    # context.connectivity.admin_auth_token = auth_key
    # context.connectivity.server_address = '10.5.1.2'
    # context.connectivity.cloudshell_api_port = api_port
    context.resource.attributes['{}SNMP Version'.format(shell_name)] = '2'
    # context.resource.attributes['{}SNMP Read Community'.format(shell_name)] = 'public'
    context.resource.attributes['{}SNMP Write Community'.format(shell_name)] = 'public'
    context.resource.attributes['{}SNMP V3 User'.format(shell_name)] = 'test_user'
    context.resource.attributes['{}SNMP V3 Password'.format(shell_name)] = 'S3c@sw0rd'
    context.resource.attributes['{}SNMP V3 Private Key'.format(shell_name)] = 'S3c@tw0rd'
    context.resource.attributes['{}SNMP V3 Authentication Protocol'.format(shell_name)] = 'MD5'
    context.resource.attributes['{}SNMP V3 Privacy Protocol'.format(shell_name)] = 'DES'
    # context.resource.attributes['{}CLI Connection Type'.format(shell_name)] = 'telnet'
    context.resource.attributes['{}CLI Connection Type'.format(shell_name)] = 'ssh'
    # context.resource.attributes['{}CLI TCP Port'.format(shell_name)] = 17000
    context.resource.attributes['{}Enable SNMP'.format(shell_name)] = 'False'
    # context.resource.attributes['{}Enable SNMP'.format(shell_name)] = 'True'
    context.resource.attributes['{}Disable SNMP'.format(shell_name)] = 'False'
    context.resource.attributes['{}Sessions Concurrency Limit'.format(shell_name)] = '1'#geetha changed this to 2
 #gk using following for ssh to device from jumphost
    context.resource.attributes['{}Console Server IP Address'.format(shell_name)] = '172.28.17.251'
    context.resource.attributes['{}Console User'.format(shell_name)] = 'autouser'
    context.resource.attributes['{}Console Password'.format(shell_name)] = 'Aut@ntf@1010'
    # context.resource.attributes['{}Console Port'.format(shell_name)] = 17000
    return context
#gk calling gpon driver
if __name__ == '__main__':
    driver = HfcShellDriver()
    context = gen_context(driver.SHELL_NAME + '.')
    driver.initialize(context)
    # driver = JunosResourceDriver()

    # driver.save(context, '','')
    # print(driver.send_custom_command(context, 'show run'))
    # print(driver.send_custom_command(context, 'show interfaces'))
    # print(driver.update_firmware(context, 'tftp://yar:pass@10.2.5.6:8435/test_path/test_file/323', ''))
    with patch('driver.get_api') as get_api:
        get_api.return_value = type('api', (object,), {
            'DecryptPassword': lambda self, pw: type('Password', (object,), {'Value': pw})()})()
        out = driver.get_inventory(context)
        # print(inv)
        # out = driver.save(context, '', '', None)
        # out = driver.ApplyConnectivityChanges(context, request)
        # out = driver.restore(context, 'ftp://juniper:juniper@192.168.85.16/dsada-running-300317-184311', None, None, None)
        # out = driver.load_firmware(context, 'ftp://ipss:ipss@10.215.100.100/JunOS/16/junos-install-mx-x86-64-16.1R5.7.tgz', None)
        # out = driver.load_firmware(context, 'ftp://ipss:ipss@10.215.100.100/Cloudshell/JunOS/17/junos-install-mx-x86-64-17.1R2-S6.tgz', None)
        # out = driver.run_custom_command(context, 'show interfaces')
        print(out)

        # inventory = driver.get_inventory(context)
        # print(inventory)
        # print(driver.save(context, '', 'running'))
        # print(driver.save(context, '', 'startup'))
        # print(driver.save(context, '', ''))
        # print(driver.restore(context, 'ftp://junos:junos@192.168.85.47/TestAireOS-running-080816-191745', 'running', 'override'))
        # print(driver.restore(context, 'tftp://172.25.10.96/AireOS_test/TestAireOS-running-210716-160651', 'running', 'override'))
        # print(driver.ApplyConnectivityChanges(context, request_range))
        # Thread(target=driver.send_custom_command, args=(context, 'show interfaces')).start()
        # Thread(target=driver.update_firmware, args=(context, 'tftp://yar:pass@10.2.5.6:8435/test_path/test_file/323', '')).start()
        # time.sleep(1)
        # Thread(target=driver.get_inventory, args=(context,)).start()
        # Thread(target=driver.get_inventory, args=(context,)).start()
        # Thread(target=driver.get_inventory, args=(context,)).start()
        # Thread(target=driver.restore, args=(context, 'show interfaces', 'rer', 'rer')).start()
        # Thread(target=driver.get_inventory, args=(context,)).start()
        # Thread(target=driver.get_inventory, args=(context,)).start()

        # Thread(target=driver.save, args=(context, '', '')).start()
        # Thread(target=driver.send_custom_command, args=(context, 'fwrfwef fwe')).start()
        # Thread(target=driver.send_custom_command, args=(context, 'show interfaces')).start()
        # Thread(target=driver.send_custom_command, args=(context, 'help')).start()
        # Thread(target=driver.send_custom_command, args=(context, 'help')).start()
        # MyThread(target=driver.send_custom_command, args=(context, 'show run')).start()

        # MyThread(target=driver.send_custom_command, args=(context, 'show version')).start()
        # MyThread(target=driver.send_custom_command, args=(context, 'show run')).start()
        # MyThread(target=driver.send_custom_command, args=(context, 'show version')).start()
        # MyThread(target=driver.send_custom_command, args=(context, 'show run')).start()
        # MyThread(target=driver.send_custom_command, args=(context, 'show version')).start()

        # Thread(target=driver.send_custom_command, args=(context, 'help')).start()
        # Thread(target=driver.send_custom_command, args=(context, 'help')).start()
        # Thread(target=driver.send_custom_command, args=(context, 'help')).start()
        # [{<weakref at 0x7f08db4e7e68; to '_MainThread' at 0x7f08de6c72d0>: <cloudshell.cli.session.session_proxy.ReturnToPoolProxy object at 0x7f08dc294a90>}, [<cloudshell.cli.session.session_proxy.ReturnToPoolProxy object at 0x7f08dc294a90>, <logging.Logger object at 0x7f08dc294910>, <cloudshell.cli.session.connection_manager.ConnectionManager object at 0x7f08dc294850>], (<cloudshell.networking.juniper.cli.juniper_cli_service.JuniperCliService object at 0x7f08dc280d10>, <cloudshell.cli.session.session_proxy.ReturnToPoolProxy object at 0x7f08dc294a90>, <logging.Logger object at 0x7f08dc294910>, <cloudshell.cli.session.connection_manager.ConnectionManager object at 0x7f08dc294850>), (<cloudshell.networking.juniper.cli.juniper_cli_service.JuniperCliService object at 0x7f08dc280d10>, <cloudshell.cli.session.session_proxy.ReturnToPoolProxy object at 0x7f08dc294a90>, <logging.Logger object at 0x7f08dc294910>, <cloudshell.cli.session.connection_manager.ConnectionManager object at 0x7f08dc294850>), <frame object at 0xe507e0>, <frame object at 0x1006280>]
        # [{<weakref at 0x7f1a3ceb8aa0; to '_MainThread' at 0x7f1a400982d0>: <cloudshell.cli.session.session_proxy.ReturnToPoolProxy object at 0x7f1a3dc65a50>}, <frame object at 0x2803ea0>, {'logger': <logging.Logger object at 0x7f1a3dc658d0>, 'session': <cloudshell.cli.session.session_proxy.ReturnToPoolProxy object at 0x7f1a3dc65a50>}, <frame object at 0x27147a0>, {'logger': <logging.Logger object at 0x7f1a3dc658d0>, 'session': <cloudshell.cli.session.session_proxy.ReturnToPoolProxy object at 0x7f1a3dc65a50>, 'expected_map': None}, <frame object at 0x2874d80>, <cell at 0x7f1a3cb74868: ReturnToPoolProxy object at 0x7f1a3dc65a50>, [<cloudshell.cli.session.session_proxy.ReturnToPoolProxy object at 0x7f1a3dc65a50>, <logging.Logger object at 0x7f1a3dc658d0>, <cloudshell.cli.session.connection_manager.ConnectionManager object at 0x7f1a3dc65810>], (<cloudshell.networking.juniper.cli.juniper_cli_service.JuniperCliService object at 0x7f1a3dc52cd0>, <cloudshell.cli.session.session_proxy.ReturnToPoolProxy object at 0x7f1a3dc65a50>, <logging.Logger object at 0x7f1a3dc658d0>, <cloudshell.cli.session.connection_manager.ConnectionManager object at 0x7f1a3dc65810>), (<cloudshell.networking.juniper.cli.juniper_cli_service.JuniperCliService object at 0x7f1a3dc52cd0>, <cloudshell.cli.session.session_proxy.ReturnToPoolProxy object at 0x7f1a3dc65a50>, <logging.Logger object at 0x7f1a3dc658d0>, <cloudshell.cli.session.connection_manager.ConnectionManager object at 0x7f1a3dc65810>), <frame object at 0x28040f0>, <frame object at 0x28732c0>, {'logger': <logging.Logger object at 0x7f1a3dc658d0>, 'session': <cloudshell.cli.session.session_proxy.ReturnToPoolProxy object at 0x7f1a3dc65a50>}]
