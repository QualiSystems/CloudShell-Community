#from access.command_actions.autoload_actions import AutoloadActions
#from access.helpers.autoload_helper import AutoloadHelper

from hfc.command_actions.autoload_actions import AutoloadActions
from hfc.helpers.autoload_helper import AutoloadHelper



class HfcAutoloadFlow(object):
    def __init__(self, cli_handler, logger):
        self._cli_handler = cli_handler
        self._logger = logger

    def execute_flow(self, supported_os, shell_name, shell_type, resource_name):
        with self._cli_handler.default_mode_service() as cli_service:
            autoload_actions = AutoloadActions(cli_service, self._logger)
            card_table = autoload_actions.show_card_table()
            slot_info = {}
            slot_desc_info = {}
            for slot_data in card_table:
                if not slot_data.__contains__('empty'):#gk
                    #if not slot_data.__contains__('nant-e'):  # gk
                    #if not slot_data.__contains__(9):
                        slot_info[slot_data]=autoload_actions.show_port_table(slot_data[0])

        #slot_desc_info = autoload_actions.get_port_description()
        #print slot_desc_info
        autoload_helper = AutoloadHelper(shell_name, shell_type, resource_name, slot_info, self._logger)
        return autoload_helper.discover()
        # return card_table, slot_info
   #problem?