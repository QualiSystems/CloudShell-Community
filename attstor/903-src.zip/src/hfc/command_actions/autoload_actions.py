import re
import operator
#import numpy
from cloudshell.cli.command_template.command_template_executor import CommandTemplateExecutor
#import cli.command_templates.autoload as command_templates
#import sys

#sys.path.insert(0, 'E:\SHELLS\dslam-shell\dslam\src')
import hfc.command_templates.autoload as command_templates

class AutoloadActions(object):
    """
    Autoload actions
    """

    # gk using this for cli service
    def __init__(self, cli_service, logger):
        """
        :param cli_service: default mode cli_service
        :type cli_service: CliService
        :param logger:
        :type logger: Logger
        :return:
        """
        self._cli_service = cli_service
        self._logger = logger
#gk using the default command mode class


    def show_card_table(self):

        output1 = CommandTemplateExecutor(self._cli_service, command_templates.LOGIN_CMD).execute_command()
        output = CommandTemplateExecutor(self._cli_service, command_templates.SHOW_CARD).execute_command()
        my_tab2 = ['01', '02']
        #table1 = re.findall(r'^[0-9]\s|empty|ndls-e|ndps-c|nant-e|sdlt-d|srnt-c|ndlt-f|ndlt-j|rant-a|NDPS-B|SDLT-E|SRNT-E|NDLS-E|RDLS-A', output, re.MULTILINE | re.IGNORECASE)
        #card_list1=['nta','nant-e','srnt-c','srnt-e','rant-a']
        nta_table1 = re.findall(r'^[0-9]\s|nant-e|srnt-c|srnt-e|rant-a+\s+yes|rani-a+\s+yes', output, re.MULTILINE | re.IGNORECASE)
        nta_table2 = re.findall(r'^[0-9]\s|nant-e|srnt-c|srnt-e|rant-a|rani-a', str(nta_table1), re.MULTILINE | re.IGNORECASE)
        ##nta_table = re.findall(r'^[0-9]\s|nt-a\s+[a-z]+-+[a-z]', output, re.MULTILINE | re.IGNORECASE)
        #^[0-9]\s|nt-a\s+[a-z]+-+[a-z]

        #lt_table1 = re.findall(r'^[0-9]\s|empty|sdlt-e+\s+yes|ndls-e+\s+yes|bdlt-f+\s+yes|ndps-b+\s+yes|sdlt-d+\s+yes|ndps-c+\s+yes|ndls-e+\s+yes|ndps-c+\s+yes|rdls-a+\s+yes|ndlt-f+\s+yes', output, re.MULTILINE | re.IGNORECASE)

        lt_table1 = re.findall(r'^[0-9]\s|\d+\s+sdlt-e+\s+yes|\d+\s+ndls-e+\s+yes|\d+\s+bdlt-f+\s+yes|\d+\s+ndps-b+\s+yes|\d+\s+sdlt-d+\s+yes|\d+\s+ndps-c+\s+yes|\d+\s+ndls-e+\s+yes|\d+\s+ndps-c+\s+yes|\d+rdls-a+\s+yes|\d+\sndlt-f+\s+yes', output, re.MULTILINE | re.IGNORECASE)

        lt_table2 = re.findall(r'^[0-9]\s|\d+\s+sdlt-e|\d+\s+ndls-e|\d+\s+bdlt-f|\d+\s+ndps-b|\d+\s+sdlt-d|\d+\s+ndps-c|\d+\s+ndls-e|\d+\s+ndps-c|\d+\s+rdls-a|\d+\s+ndlt-f', str(lt_table1), re.MULTILINE | re.IGNORECASE)

        lt_table3 = re.findall(r'^[0-9]\s|\d', str(lt_table2), re.MULTILINE | re.IGNORECASE)
        lt_table4 = re.findall(r'^[0-9]\s|sdlt-e|ndls-e|bdlt-f|ndps-b|sdlt-d|ndps-c|ndls-e|ndps-c|rdls-a|ndlt-f', str(lt_table2), re.MULTILINE | re.IGNORECASE)
        lt_slot_card=zip(lt_table3, lt_table4)
        nta_out1 = zip(my_tab2, nta_table2)
        table_out1=[]
        for item in nta_out1:
            if not item.__contains__('empty'):
              table_out1.append(item)
        #numpy.arange(11, 17, 0.5)


        lt_len=len(lt_table2)
        #num_of_ltcards= range(1, total_lt_card+1)
        #lt_out = zip(num_of_ltcards, lt_table2)
        for item in lt_slot_card:
          table_out1.append(item)
        print table_out1
        return table_out1

    def show_port_table(self, slot_id):
        print slot_id
        if slot_id!='01' and slot_id !='02' and slot_id !=9 and slot_id !='9':
            output = CommandTemplateExecutor(self._cli_service, command_templates.SHOW_PORT).execute_command()
            port_table = re.findall(r'xdsl-line:\d\/\d\/\d\/\d{1,2}', output, re.MULTILINE | re.IGNORECASE)
            clean_port_table = re.findall(r'\d\/\d\/\d\/\d{1,2}', str(port_table), re.MULTILINE | re.IGNORECASE)
            port_size=len(clean_port_table)
            count1 = 0
            clean_lst1=[]
            clean_lst2=[]
            while count1 < port_size:
                port_val1=clean_port_table[count1].split('/', 4)
                count1 += 1
                if int(port_val1[2])==int(slot_id):
                    #clean_lst1.append(port_val1[2])
                    clean_lst2.append(port_val1[3])

                 #my_tab=zip(clean_lst1,clean_lst2)
                    my_tab=clean_lst2


        else:
            #if slot_id != '9':
                #clean_lst1=[slot_id]
                clean_lst2=['1']
                #my_tab = zip(clean_lst1,clean_lst2)
                my_tab=clean_lst2

        return my_tab


    