from cloudshell.cli.cli import CLI
from cloudshell.cli.command_mode import CommandMode
from cloudshell.cli.session.ssh_session import SSHSession

if __name__ == '__main__':
    jump_host_username = 'autouser'
    jump_host_password = 'Aut@ntf@1010'
    jump_host_host = '172.28.18.210'
    device_host = '172.28.17.251'
    device_user = 'autouser'
    device_password = 'Aut@ntf@1010'

    jump_host_mode = CommandMode(r'[-a-z-0-9A-Z.$#\s:]')
    device_host_default_mode = CommandMode(r'[-a-z-0-9A-Z.$#]', enter_command='ssh {}@{}'.format(device_user, device_host),
                                               exit_command='exit',
                                               enter_action_map={
                                                   r'password:': lambda session, logger: session.send_line(
                                                       device_password, logger)})
    device_host_enable_mode = CommandMode(r'[-a-z-0-9A-Z.$#\s:]', enter_command='', exit_command='exit')

    device_host_default_mode.add_child_node(device_host_enable_mode)
    jump_host_mode.add_child_node(device_host_default_mode)

    cli = CLI()

    ssh_session = SSHSession(jump_host_host, jump_host_username, jump_host_password)
    with cli.get_session([ssh_session], device_host_enable_mode) as session:

        print session.send_command('')


