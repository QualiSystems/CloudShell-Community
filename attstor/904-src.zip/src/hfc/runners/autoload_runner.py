#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
sys.path.append('E:\SHELLS\dslam-shell\src')
#sys.path.insert(0, 'E:\SHELLS\dslam-shell\src')
from cloudshell.devices.runners.autoload_runner import AutoloadRunner

from hfc.flows.autoload_flow import HfcAutoloadFlow

class HfcAutoloadRunner(AutoloadRunner):
    def __init__(self, cli_handler, logger, resource_config):
        super(HfcAutoloadRunner, self).__init__(resource_config, logger)
        self._cli_handler = cli_handler

    @property
    def autoload_flow(self):
        return HfcAutoloadFlow(self._cli_handler, self._logger)
