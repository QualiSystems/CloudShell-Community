from cloudshell.cli.command_template.command_template import CommandTemplate

ERROR_MAP = {}
ACTION_MAP = {}
SHOW_CARD = CommandTemplate('show linecard status', ACTION_MAP, ERROR_MAP)
SHOW_PORT = CommandTemplate('show port status full', ACTION_MAP, ERROR_MAP)
LOGIN_CMD = CommandTemplate('ssh autouser@172.28.17.251', ACTION_MAP, ERROR_MAP)
#sshpass -p Aut@ntf@1010