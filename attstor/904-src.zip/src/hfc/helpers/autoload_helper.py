from collections import defaultdict

from cloudshell.devices.autoload.autoload_builder import AutoloadDetailsBuilder
from cloudshell.devices.standards.networking.autoload_structure import GenericResource, GenericChassis, GenericModule, \
    GenericSubModule, GenericPort

#from cloudshell.api.cloudshell_api import CloudShellAPISession, ResourceAttributesUpdateRequest, AttributeNameValue



class AutoloadHelper(object):
    CHASSIS_ID = 1

    def __init__(self, shell_name, shell_type, resource_name, resource_table, logger):
        self._shell_name = shell_name
        self._resource_name = resource_name
        # self._shell_type = shell_type
        self._resource_table = resource_table
        self._resource = GenericResource(shell_name=shell_name, shell_type=shell_type, name=resource_name, unique_id=resource_name)
        self.__ports_table = {}
        self.logger = logger
        self.slot_desc_info = slot_desc

    @property
    def _ports_table(self):
        if not self.__ports_table:
            for ports in self._resource_table.values():
                self.__ports_table.update(self._sort_port_table(ports))
        return self.__ports_table

    def _sort_port_table(self, ports_data):
        ports_table = defaultdict(list)
        for port_index in ports_data:
            port_index_list = port_index.split('/')
            """if len(port_index_list) == 3:
                module_id, submodule_id, port_id = port_index_list
                ports_table[(module_id, submodule_id)].append(port_id)
            elif len(port_index_list) == 2:"""
            module_id, port_id = port_index_list
            ports_table[(module_id)].append(port_id)

            return ports_table

    def _build_root(self):
        self._resource.vendor='Dslam Vendor'
        self._resource.model='Access'
        self._resource.os_version=''

    def _build_chassis(self):
        chassis = GenericChassis(shell_name=self._shell_name,
                                 name="Chassis {}".format(self.CHASSIS_ID),
                                 unique_id="{0}.{1}.{2}".format(self._resource_name, "chassis", self.CHASSIS_ID))
        self._resource.add_sub_resource(self.CHASSIS_ID, chassis)
        return chassis

    def _build_modules(self, chassis):
        modules = {}
        for module_id, module_descr in self._resource_table:

            if module_id!='01' and module_id!='02' and module_id!=9 and module_id!='9':
            #if module_id.isdigit():
                module = GenericModule(shell_name=self._shell_name,
                                       name="Lt {}".format(module_id),
                                       unique_id="{}.Lt_{}".format(self._resource_name, module_id))
                module.model=module_descr
                chassis.add_sub_resource(module_id, module)
                modules[module_id] = module

                #added
                key=(module_id, module_descr)
                ports=self._resource_table[key]
                for port_id in ports:
                    port = GenericPort(shell_name=self._shell_name, name="Port {}".format(port_id), unique_id='{0}.module_{1}.Port_{2}'.format(self._resource_name, module_id, port_id))
                    port.duplex = 'Full'
                    port.port_description = 'XDSL. Line'

                    module.add_sub_resource(port_id, port)
                 #added
             ####################
            else:  # gk added
                #if module_id == 'A':
                 #   module_id = '01'

                #if module_id == 'B':
                 #   module_id = '02'

                module = GenericModule(shell_name=self._shell_name, name="Card {}".format(module_id),
                                       unique_id="{}.module_{}".format(self._resource_name, module_id))

                if module_id == '01':
                    module.model = 'Nt card - ' + module_descr

                if module_id == '02':
                    module.model = 'Nt card - ' + module_descr

                if module_id == 9:
                    module.model = 'vectoring - ' + module_descr
                if module_id == '9':
                    module.model = 'vectoring - ' + module_descr

                chassis.add_sub_resource(module_id, module)
                modules[module_id] = module
                ####
               ##### ports = ['1']
                #####for port_id in ports:
                   #### port = GenericPort(shell_name=self._shell_name, name="Port {}".format(port_id),
                       ####                unique_id='{0}.module_{1}.Port_{2}'.format(self._resource_name, module_id,
                           ######                                                      port_id))
                    # port_module.add_sub_resource(port_id, port)
             #####################
        return modules

    # module data is key and ports data is value
    def _build_submodules(self, modules):
        submodules = {}
        my_port_list = ['1', '2', '3', '4', '5', '6', '7', '8']
        for key in modules:
           if key!='01' and key!='02':
                module=modules.get(key)
                print "key: %s , value: %s" % (key, modules[key])
                for port_val in my_port_list:
                    submodule_id = port_val
                    sub_module = GenericSubModule(shell_name=self._shell_name,
                                                      name="Pon {}".format(submodule_id),
                                                      unique_id="{0}.module_{1}.Pon_{2}".format(self._resource_name, key, submodule_id))
                    module.add_sub_resource(submodule_id, sub_module)

                    submodules[(key, submodule_id)] = sub_module
           else:#ggggggggggggggg
               module = modules.get(key)
               submodule_id ='1'
               sub_module = GenericSubModule(shell_name=self._shell_name,
                                             name="Port {}".format(submodule_id),
                                             unique_id="{0}.module_{1}.Port_{2}".format(self._resource_name, key,
                                                                                       submodule_id))
               module.add_sub_resource(submodule_id, sub_module)

               submodules[(key, submodule_id)] = sub_module#ggggggggggggggggg
        return submodules


    def _build_ports(self, modules, submodules):
        """for module_ent, ports in self._ports_table.iteritems():
            module_id = module_ent[0]
            if len(module_ent) == 2:
                submodule_id = module_ent[1]
                port_module = submodules.get((module_id, submodule_id))"""
            # if len(module_ent) == 1:
            #     port_module = modules.get(module_id)
########gk jan30

        for module_id, module_descr in self._resource_table:
                key = (module_id, module_descr)
                ports = self._resource_table[key]
                for port_id in ports:
                    port = GenericPort(shell_name=self._shell_name, name="Lt {}".format(port_id),
                                       unique_id='{0}.module_{1}.port_{2}'.format(self._resource_name, module_id, port_id))
                    module = GenericModule(shell_name=self._shell_name,
                                       name="Lt {}".format(module_id),
                                       unique_id="{}.Lt_{}".format(self._resource_name, module_id))
                    modules[module_id] = module
                    module.add_sub_resource(port_id, port)

                """if port_module:
                    for port_id in ports:
                        port = GenericPort(shell_name=self._shell_name,
                                           name="Pon {}".format(port_id),
                                           unique_id='{0}.module_{1}.submodule_{2}.Pon_{3}'.format(self._resource_name, module_id, submodule_id, port_id))
                        port_module.add_sub_resource(port_id, port)"""

    def _log_autoload_details(self, autoload_details):
        """
        Logging autoload details
        :param autoload_details:
        :return:
        """
        self.logger.debug('-------------------- <RESOURCES> ----------------------')
        for resource in autoload_details.resources:
            self.logger.debug(
                '{0:15}, {1:20}, {2}'.format(resource.relative_address, resource.name, resource.unique_identifier))
        self.logger.debug('-------------------- </RESOURCES> ----------------------')

        self.logger.debug('-------------------- <ATTRIBUTES> ---------------------')
        for attribute in autoload_details.attributes:
            self.logger.debug('-- {0:15}, {1:60}, {2}'.format(attribute.relative_address, attribute.attribute_name,
                                                              attribute.attribute_value))
        self.logger.debug('-------------------- </ATTRIBUTES> ---------------------')

    def discover(self):
        chassis = self._build_chassis()
        modules = self._build_modules(chassis)#LT card
        #submodules = self._build_submodules(modules)
        #self._build_ports(modules, modules) #DSL ports
        #gkself._build_ports(modules)#gk added
        autoload_details = AutoloadDetailsBuilder(self._resource).autoload_details()
        self._log_autoload_details(autoload_details)
        return autoload_details
